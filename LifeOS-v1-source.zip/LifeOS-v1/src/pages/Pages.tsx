import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowDownLeft, ArrowUpRight, BookOpen, CalendarDays, Check, CheckCircle2, Circle, Clock3, ExternalLink, Lightbulb, Link2, LoaderCircle, Moon, Plus, Search, Send, Sparkles, Trash2, X } from 'lucide-react';
import { httpsCallable } from 'firebase/functions';
import type { DataStore } from '../lib/store';
import { functions, firebaseReady } from '../lib/firebase';
import { dateLabel, isoDate, money, sleepLabel, sleepMinutes, type CalendarEvent, type Note, type SleepRecord, type Task, type Transaction } from '../lib/types';

type CommonProps = { store: DataStore; requestAdd?: number };
function PageIntro({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-intro"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="muted">{subtitle}</p></div>{action}</div>;
}
function Empty({ title, detail }: { title: string; detail: string }) {
  return <div className="empty"><div className="empty-glyph"><Lightbulb size={24}/></div><h3>{title}</h3><p>{detail}</p></div>;
}
function Dialog({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return <div className="overlay" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="dialog"><div className="section-heading"><h2>{title}</h2><button className="icon-btn" onClick={onClose} aria-label="닫기"><X size={20}/></button></div>{children}</div></div>;
}
function DeleteButton({ onDelete }: { onDelete: () => Promise<void> }) {
  return <button className="icon-btn danger-text" aria-label="삭제" title="삭제" onClick={() => { if (window.confirm('이 기록을 삭제할까요?')) void onDelete().catch(e => alert(e.message)); }}><Trash2 size={17}/></button>;
}
function ErrorText({ error }: { error: string }) { return error ? <p className="alert">{error}</p> : null; }

export function CalendarPage({ store, requestAdd }: CommonProps) {
  const [month, setMonth] = useState(isoDate().slice(0, 7));
  const [type, setType] = useState<'task' | 'event'>('task');
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [modal, setModal] = useState(false);
  const [title, setTitle] = useState('');
  const [due, setDue] = useState(isoDate());
  const [time, setTime] = useState('');
  const [priority, setPriority] = useState<'low' | 'normal' | 'high'>('normal');
  const [details, setDetails] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  function open(kind: 'task' | 'event', task?: Task, event?: CalendarEvent) {
    setType(kind); setEditingTask(task || null); setEditingEvent(event || null);
    setTitle(task?.title || event?.title || ''); setDue(task?.dueDate || event?.date || isoDate());
    setTime(event?.time || ''); setDetails(task?.notes || event?.details || ''); setPriority(task?.priority || 'normal'); setError(''); setModal(true);
  }
  useEffect(() => { if (requestAdd) open('task'); }, [requestAdd]);
  async function save(e: FormEvent) {
    e.preventDefault(); if (!title.trim()) return;
    setSaving(true); setError('');
    try {
      if (type === 'task') {
        const data = { title: title.trim(), dueDate: due, priority, notes: details.trim(), done: editingTask?.done ?? false };
        if (editingTask) await store.edit('tasks', editingTask.id, data); else await store.add('tasks', data);
      } else {
        const data = { title: title.trim(), date: due, time, details: details.trim() };
        if (editingEvent) await store.edit('events', editingEvent.id, data); else await store.add('events', data);
      }
      setModal(false);
    } catch (e) { setError(e instanceof Error ? e.message : '저장 실패'); } finally { setSaving(false); }
  }
  const tasks = [...store.tasks].filter(t => !t.dueDate || t.dueDate.startsWith(month)).sort((a,b) => Number(a.done) - Number(b.done) || a.dueDate.localeCompare(b.dueDate));
  const events = [...store.events].filter(x => x.date.startsWith(month)).sort((a,b) => (a.date + a.time).localeCompare(b.date + b.time));
  const allDone = store.tasks.length && store.tasks.filter(t => t.done).length;
  return <div className="stack-lg">
    <PageIntro eyebrow="YOUR PLANNER" title="일정과 할 일" subtitle="중요한 약속과 해야 할 일을 놓치지 않도록 정리하세요." action={<button className="btn primary" onClick={() => open('task')}><Plus size={18}/> 새로 추가</button>}/>
    <div className="stats-grid two"><div className="summary-card"><small>완료한 할 일</small><strong>{allDone || 0} / {store.tasks.length}</strong><span>작은 성취를 계속 쌓아가세요</span></div><div className="summary-card"><small>이번 달 등록 일정</small><strong>{events.length}개</strong><span>{month.replace('-', '년 ')}월</span></div></div>
    <div className="filter-row"><label className="input-inline"><CalendarDays size={17}/><input aria-label="조회 월" type="month" value={month} onChange={e => setMonth(e.target.value)}/></label><div className="filter-actions"><button className="btn secondary" onClick={() => open('event')}><Plus size={16}/> 일정</button><button className="btn secondary" onClick={() => open('task')}><Plus size={16}/> 할 일</button></div></div>
    <div className="two-col">
      <section className="panel"><div className="section-heading"><h2>할 일 <span className="count">{tasks.length}</span></h2></div>
        {tasks.length ? <div className="record-list">{tasks.map(t => <div className={'record-row ' + (t.done ? 'completed' : '')} key={t.id}>
          <button className="check-btn" onClick={() => void store.edit('tasks', t.id, { done: !t.done }).catch(e => alert(e.message))} aria-label={t.done ? '완료 취소' : '할 일 완료'}>{t.done ? <CheckCircle2 size={23}/> : <Circle size={23}/>}</button>
          <button className="record-main" onClick={() => open('task', t)}><strong>{t.title}</strong><small>{t.dueDate ? dateLabel(t.dueDate) : '날짜 미지정'} · <span className={'priority ' + t.priority}>{t.priority === 'high' ? '중요' : t.priority === 'normal' ? '보통' : '낮음'}</span></small></button>
          <DeleteButton onDelete={() => store.remove('tasks', t.id)}/></div>)}</div> : <Empty title="아직 할 일이 없어요" detail="오른쪽 위에서 새로운 할 일을 추가하세요."/>}
      </section>
      <section className="panel"><div className="section-heading"><h2>등록된 일정 <span className="count">{events.length}</span></h2></div>
        {events.length ? <div className="record-list">{events.map(e => <div className="record-row" key={e.id}><span className="event-glyph"><CalendarDays size={18}/></span><button className="record-main" onClick={() => open('event', undefined, e)}><strong>{e.title}</strong><small>{dateLabel(e.date)} {e.time} {e.details ? `· ${e.details}` : ''}</small></button><DeleteButton onDelete={() => store.remove('events', e.id)}/></div>)}</div> : <Empty title="이번 달 일정이 없어요" detail="약속이나 중요한 날짜를 추가하세요."/>}
      </section>
    </div>
    {modal && <Dialog title={editingTask || editingEvent ? '기록 수정' : '새 기록 추가'} onClose={() => setModal(false)}><div className="segmented"><button className={type==='task'?'active':''} onClick={()=>{ setType('task'); setEditingEvent(null); }}>할 일</button><button className={type==='event'?'active':''} onClick={()=>{ setType('event'); setEditingTask(null); }}>일정</button></div><form className="stack-md" onSubmit={save}>
      <label>제목<input value={title} maxLength={120} onChange={e=>setTitle(e.target.value)} placeholder={type==='task'?'해야 할 일':'일정 이름'} required/></label>
      <div className="form-grid"><label>날짜<input type="date" value={due} onChange={e=>setDue(e.target.value)} required/></label>{type==='event' ? <label>시간 (선택)<input type="time" value={time} onChange={e=>setTime(e.target.value)}/></label> : <label>우선순위<select value={priority} onChange={e=>setPriority(e.target.value as typeof priority)}><option value="low">낮음</option><option value="normal">보통</option><option value="high">중요</option></select></label>}</div>
      <label>메모 (선택)<textarea rows={3} maxLength={2000} value={details} onChange={e=>setDetails(e.target.value)} placeholder="추가로 기억할 내용"/></label><ErrorText error={error}/><button className="btn primary wide" disabled={saving}>{saving?'저장 중...':'저장하기'}</button>
    </form></Dialog>}
  </div>;
}

const categoryOptions = ['식비','교통','쇼핑','구독','생활','취미','교육','기타'];
export function FinancePage({ store, requestAdd }: CommonProps) {
  const [month, setMonth] = useState(isoDate().slice(0,7));
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [kind,setKind] = useState<'expense'|'income'>('expense');
  const [title,setTitle] = useState(''); const [amount,setAmount] = useState('');
  const [category,setCategory] = useState('식비'); const [date,setDate] = useState(isoDate());
  const [error,setError] = useState(''); const [saving,setSaving] = useState(false);
  const savedBudget = store.budgets.find(b => b.month === month);
  const budget = savedBudget?.amount || 0;
  const [budgetInput,setBudgetInput] = useState('');
  useEffect(() => { setBudgetInput(savedBudget ? String(savedBudget.amount) : ''); }, [savedBudget?.amount, month]);
  function open(row?: Transaction) { setEditing(row||null); setKind(row?.kind||'expense'); setTitle(row?.title||''); setAmount(row?String(row.amount):''); setCategory(row?.category||'식비'); setDate(row?.date||isoDate()); setError(''); setModal(true); }
  useEffect(() => { if(requestAdd) open(); }, [requestAdd]);
  async function save(e: FormEvent) { e.preventDefault(); const parsed = Number(amount); if (!Number.isFinite(parsed) || parsed <= 0 || parsed > 1e12) { setError('올바른 금액을 입력하세요.'); return; } setSaving(true); setError('');
    try { const data={ title: title.trim(), amount: Math.round(parsed), kind, category: kind==='income'?'수입':category, date }; if(editing) await store.edit('transactions',editing.id,data); else await store.add('transactions',data); setModal(false); }
    catch(e) {setError(e instanceof Error?e.message:'저장 실패');} finally {setSaving(false);} }
  const rows=[...store.transactions].filter(x=>x.date.startsWith(month)).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
  const spent=rows.filter(x=>x.kind==='expense').reduce((s,x)=>s+x.amount,0); const income=rows.filter(x=>x.kind==='income').reduce((s,x)=>s+x.amount,0);
  const groups=categoryOptions.map(name=>({name,total:rows.filter(x=>x.kind==='expense'&&x.category===name).reduce((s,x)=>s+x.amount,0)})).filter(x=>x.total>0).sort((a,b)=>b.total-a.total);
  const max=Math.max(...groups.map(g=>g.total),1);
  return <div className="stack-lg"><PageIntro eyebrow="MY FINANCES" title="금융과 지출" subtitle="수입과 지출을 간편하게 기록하고 소비 습관을 파악하세요." action={<button className="btn primary" onClick={()=>open()}><Plus size={18}/> 거래 추가</button>}/>
    <div className="stats-grid three"><div className="summary-card"><small>이번 달 지출</small><strong>{money(spent)}</strong><span>총 {rows.filter(x=>x.kind==='expense').length}건</span></div><div className="summary-card"><small>이번 달 수입</small><strong>{money(income)}</strong><span>수입 기록 합계</span></div><div className="summary-card"><small>순수입</small><strong>{money(income-spent)}</strong><span>수입 - 지출</span></div></div>
    <div className="filter-row"><label className="input-inline"><CalendarDays size={17}/><input aria-label="조회 월" type="month" value={month} onChange={e=>setMonth(e.target.value)}/></label></div>
    <div className="two-col"><section className="panel"><div className="section-heading"><h2>거래 기록</h2><span className="count">{rows.length}</span></div>
      {rows.length?<div className="record-list">{rows.map(t=><div className="record-row" key={t.id}><span className={'money-icon '+t.kind}>{t.kind==='income'?<ArrowDownLeft size={19}/>:<ArrowUpRight size={19}/>}</span><button className="record-main" onClick={()=>open(t)}><strong>{t.title}</strong><small>{dateLabel(t.date)} · {t.category}</small></button><span className={'row-amount '+t.kind}>{t.kind==='income'?'+':'−'}{money(t.amount)}</span><DeleteButton onDelete={()=>store.remove('transactions',t.id)}/></div>)}</div>:<Empty title="아직 거래 기록이 없어요" detail="작은 지출부터 기록해 보세요."/>}</section>
      <section className="panel"><div className="section-heading"><h2>지출 분석</h2></div><div className="budget-box"><div><small>이번 달 예산 (기기 간 동기화)</small><strong>{budget>0 ? money(budget) : '설정되지 않음'}</strong></div><div className="budget-control"><input type="number" min="0" step="1000" aria-label="월 예산" placeholder="예산 입력" value={budgetInput} onChange={e=>setBudgetInput(e.target.value)}/><button className="btn secondary" onClick={()=>{const v=Math.max(0,Number(budgetInput)||0);void (savedBudget?store.edit('budgets',savedBudget.id,{amount:v}):store.add('budgets',{month,amount:v})).catch(e=>alert(e.message));}}>적용</button></div>{budget>0&&<><div className="progress-track"><div style={{width:`${Math.min(100,spent/budget*100)}%`}} /></div><small>예산의 {Math.round(spent/budget*100)}% 사용 · 잔여 {money(budget-spent)}</small></>}</div>
        <p className="subhead">카테고리별 지출</p>{groups.length?groups.map(g=><div className="bar-row" key={g.name}><span>{g.name}</span><div className="bar-track"><div style={{width:`${g.total/max*100}%`}}/></div><strong>{money(g.total)}</strong></div>):<Empty title="분석할 지출이 없어요" detail="거래를 기록하면 분류별 소비가 표시됩니다."/>}
      </section></div>
    {modal&&<Dialog title={editing?'거래 수정':'수입·지출 기록'} onClose={()=>setModal(false)}><form className="stack-md" onSubmit={save}><div className="segmented"><button type="button" className={kind==='expense'?'active':''} onClick={()=>setKind('expense')}>지출</button><button type="button" className={kind==='income'?'active':''} onClick={()=>setKind('income')}>수입</button></div><label>내역<input maxLength={100} value={title} onChange={e=>setTitle(e.target.value)} placeholder="무엇에 사용했나요?" required/></label><div className="form-grid"><label>금액 (원)<input type="number" inputMode="numeric" min="1" max="1000000000000" step="1" value={amount} onChange={e=>setAmount(e.target.value)} required/></label><label>날짜<input type="date" value={date} onChange={e=>setDate(e.target.value)} required/></label></div>{kind==='expense'&&<label>분류<select value={category} onChange={e=>setCategory(e.target.value)}>{categoryOptions.map(c=><option key={c}>{c}</option>)}</select></label>}<ErrorText error={error}/><button className="btn primary wide" disabled={saving}>{saving?'저장 중...':'저장하기'}</button></form></Dialog>}
  </div>;
}

function safeUrl(url: string) { try { const u=new URL(url); return u.protocol==='https:'||u.protocol==='http:' ? u.href : ''; } catch { return ''; } }
export function NotesPage({ store,requestAdd }: CommonProps) {
  const [q,setQ] = useState(''); const [modal,setModal]=useState(false); const [editing,setEditing]=useState<Note|null>(null);
  const [title,setTitle]=useState(''); const [content,setContent]=useState(''); const [url,setUrl]=useState(''); const [tag,setTag]=useState('');
  const [saving,setSaving]=useState(false); const [error,setError]=useState('');
  function open(note?:Note) {setEditing(note||null); setTitle(note?.title||'');setContent(note?.content||'');setUrl(note?.url||'');setTag(note?.tag||'');setError('');setModal(true);}
  useEffect(()=>{if(requestAdd)open();},[requestAdd]);
  async function save(e:FormEvent){e.preventDefault(); if(url.trim()&&!safeUrl(url.trim())){setError('주소는 http:// 또는 https:// 형식으로 입력하세요.');return;}setSaving(true);setError('');try{const record={title:title.trim(),content:content.trim(),url:url.trim(),tag:tag.trim(),pinned:editing?.pinned||false};if(editing)await store.edit('notes',editing.id,record);else await store.add('notes',record);setModal(false);}catch(e){setError(e instanceof Error?e.message:'저장 실패');}finally{setSaving(false);}}
  const notes=[...store.notes].filter(n=>[n.title,n.content,n.url,n.tag].join(' ').toLowerCase().includes(q.toLowerCase())).sort((a,b)=>Number(b.pinned)-Number(a.pinned)||b.updatedAt-a.updatedAt);
  return <div className="stack-lg"><PageIntro eyebrow="YOUR SECOND BRAIN" title="메모와 북마크" subtitle="기억하고 싶은 정보를 모으고 필요할 때 빠르게 찾으세요." action={<button className="btn primary" onClick={()=>open()}><Plus size={18}/> 새 메모</button>}/>
    <label className="searchbox"><Search size={19}/><input placeholder="제목, 내용, 태그로 검색" value={q} onChange={e=>setQ(e.target.value)}/></label>
    {notes.length?<div className="note-grid">{notes.map(n=><article className="note-card" key={n.id}><div className="note-head"><span className="note-icon">{n.url?<Link2 size={19}/>:<BookOpen size={19}/>}</span><div><button className="text-btn small" onClick={()=>void store.edit('notes',n.id,{pinned:!n.pinned}).catch(e=>alert(e.message))}>{n.pinned?'★ 고정됨':'☆ 고정'}</button><DeleteButton onDelete={()=>store.remove('notes',n.id)}/></div></div><button className="note-body" onClick={()=>open(n)}><h3>{n.title}</h3><p>{n.content||'내용 없음'}</p></button><div className="note-bottom"><span>{n.tag?`#${n.tag}`:'메모'}</span>{n.url&&<a href={safeUrl(n.url)} target="_blank" rel="noopener noreferrer" aria-label="북마크 열기" onClick={e=>e.stopPropagation()}><ExternalLink size={18}/></a>}</div></article>)}</div>:<Empty title={q?'검색 결과가 없어요':'첫 번째 메모를 작성해 보세요'} detail={q?'다른 키워드로 검색해 보세요.':'링크나 아이디어를 저장할 수 있습니다.'}/>}
    {modal&&<Dialog title={editing?'메모 수정':'새 메모 작성'} onClose={()=>setModal(false)}><form className="stack-md" onSubmit={save}><label>제목<input maxLength={140} value={title} onChange={e=>setTitle(e.target.value)} required placeholder="제목 입력"/></label><label>내용<textarea rows={6} maxLength={12000} value={content} onChange={e=>setContent(e.target.value)} placeholder="기억하고 싶은 내용을 자유롭게 기록하세요"/></label><label>웹 링크 (선택)<input type="url" value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://..."/></label><label>태그 (선택)<input maxLength={40} value={tag} onChange={e=>setTag(e.target.value)} placeholder="예: 아이디어, 읽을거리"/></label><ErrorText error={error}/><button className="btn primary wide" disabled={saving}>{saving?'저장 중...':'저장하기'}</button></form></Dialog>}
  </div>;
}

export function SleepPage({store,requestAdd}:CommonProps) {
  const [modal,setModal]=useState(false);const [editing,setEditing]=useState<SleepRecord|null>(null);
  const [date,setDate]=useState(isoDate());const [bedtime,setBedtime]=useState('23:30');const [wakeTime,setWakeTime]=useState('07:00');const [mood,setMood]=useState(3);const [memo,setMemo]=useState('');
  const [saving,setSaving]=useState(false);const [error,setError]=useState('');
  function open(row?:SleepRecord){setEditing(row||null);setDate(row?.date||isoDate());setBedtime(row?.bedtime||'23:30');setWakeTime(row?.wakeTime||'07:00');setMood(row?.mood||3);setMemo(row?.memo||'');setError('');setModal(true);}
  useEffect(()=>{if(requestAdd)open();},[requestAdd]);
  async function save(e:FormEvent){e.preventDefault();if(!sleepMinutes(bedtime,wakeTime)){setError('취침 시간과 기상 시간이 같으면 계산할 수 없어요.');return;}setSaving(true);setError('');try{const row={date,bedtime,wakeTime,mood,memo:memo.trim()};if(editing)await store.edit('sleepRecords',editing.id,row);else await store.add('sleepRecords',row);setModal(false);}catch(e){setError(e instanceof Error?e.message:'저장 실패');}finally{setSaving(false);}}
  const sorted=[...store.sleepRecords].sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
  const recent=sorted.slice(0,7);const avg=recent.length?Math.round(recent.reduce((s,r)=>s+sleepMinutes(r.bedtime,r.wakeTime),0)/recent.length):0;
  return <div className="stack-lg"><PageIntro eyebrow="WELLBEING" title="수면과 컨디션" subtitle="내 생활 리듬을 기록하고 수면 패턴을 살펴보세요." action={<button className="btn primary" onClick={()=>open()}><Plus size={18}/> 수면 기록</button>}/>
    <div className="stats-grid two"><div className="summary-card"><small>최근 {recent.length}개 기록의 평균 수면</small><strong>{recent.length?sleepLabel(avg):'기록 없음'}</strong><span>기록된 데이터 기준</span></div><div className="summary-card"><small>수면 기록 수</small><strong>{store.sleepRecords.length}개</strong><span>꾸준히 기록하고 변화를 살펴보세요</span></div></div>
    <div className="two-col"><section className="panel"><div className="section-heading"><h2>최근 수면 시간</h2></div>{recent.length?<div className="sleep-bars">{[...recent].reverse().map(r=>{const minutes=sleepMinutes(r.bedtime,r.wakeTime);return <div className="sleep-bar-col" key={r.id}><strong>{(minutes/60).toFixed(1)}h</strong><div className="sleep-track"><div style={{height:`${Math.min(100,minutes/(12*60)*100)}%`}}/></div><small>{r.date.slice(5).replace('-','/')}</small></div>;})}</div>:<Empty title="그래프가 비어 있어요" detail="수면 시간을 기록하면 그래프가 나타납니다."/>}<p className="muted small">수면 시간은 취침·기상 시간을 기준으로 계산한 추정치예요.</p></section>
    <section className="panel"><div className="section-heading"><h2>수면 기록</h2></div>{sorted.length?<div className="record-list">{sorted.map(r=><div className="record-row" key={r.id}><span className="event-glyph"><Moon size={18}/></span><button className="record-main" onClick={()=>open(r)}><strong>{dateLabel(r.date)} · {sleepLabel(sleepMinutes(r.bedtime,r.wakeTime))}</strong><small>{r.bedtime} → {r.wakeTime} · 컨디션 {['','매우 낮음','낮음','보통','좋음','매우 좋음'][r.mood]}</small></button><DeleteButton onDelete={()=>store.remove('sleepRecords',r.id)}/></div>)}</div>:<Empty title="아직 수면 기록이 없어요" detail="오늘의 수면과 컨디션을 적어 보세요."/>}</section></div>
    {modal&&<Dialog title={editing?'수면 기록 수정':'수면 기록 추가'} onClose={()=>setModal(false)}><form className="stack-md" onSubmit={save}><label>기상 날짜<input type="date" value={date} onChange={e=>setDate(e.target.value)} required/></label><div className="form-grid"><label>취침 시각<input type="time" value={bedtime} onChange={e=>setBedtime(e.target.value)} required/></label><label>기상 시각<input type="time" value={wakeTime} onChange={e=>setWakeTime(e.target.value)} required/></label></div><div className="sleep-preview"><Clock3 size={18}/> 계산된 수면 시간 <strong>{sleepLabel(sleepMinutes(bedtime,wakeTime))}</strong></div><label>기상 후 컨디션<select value={mood} onChange={e=>setMood(Number(e.target.value))}><option value={1}>1 · 매우 낮음</option><option value={2}>2 · 낮음</option><option value={3}>3 · 보통</option><option value={4}>4 · 좋음</option><option value={5}>5 · 매우 좋음</option></select></label><label>메모 (선택)<textarea rows={3} maxLength={2000} value={memo} onChange={e=>setMemo(e.target.value)} placeholder="특이한 점이 있었다면 기록하세요"/></label><ErrorText error={error}/><button className="btn primary wide" disabled={saving}>{saving?'저장 중...':'저장하기'}</button></form></Dialog>}
  </div>;
}

type ChatMessage={role:'user'|'assistant'; text:string};
const prompts=['이번 달 지출 요약','남은 할 일 알려줘','최근 수면 기록 요약'];
export function AssistantPage({store}:{store:DataStore}){
  const [messages,setMessages]=useState<ChatMessage[]>([{role:'assistant',text:'안녕하세요! LifeOS 비서예요. 기본 통계는 무료로 바로 알려드리고, 자유로운 AI 대화는 Firebase 서버 기능을 연결하면 사용할 수 있어요.'}]);
  const [query,setQuery]=useState('');const [working,setWorking]=useState(false);const [shareSummary,setShareSummary]=useState(false);
  const today=isoDate();const month=today.slice(0,7);
  const summary=useMemo(()=>({
    asOf:today,
    incompleteTasks:store.tasks.filter(t=>!t.done).length,
    dueSoonTasks:store.tasks.filter(t=>!t.done&&t.dueDate>=today&&t.dueDate<=isoDate(new Date(Date.now()+7*86400000))).length,
    monthExpense:store.transactions.filter(t=>t.kind==='expense'&&t.date.startsWith(month)).reduce((s,t)=>s+t.amount,0),
    monthIncome:store.transactions.filter(t=>t.kind==='income'&&t.date.startsWith(month)).reduce((s,t)=>s+t.amount,0),
    recentSleepHours:store.sleepRecords.length?Number((([...store.sleepRecords].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,7).reduce((s,r)=>s+sleepMinutes(r.bedtime,r.wakeTime),0)/Math.min(store.sleepRecords.length,7))/60).toFixed(1)):null,
  }),[store.tasks,store.transactions,store.sleepRecords,today,month]);
  function localAnswer(q:string){
    if(/(지출|소비|수입|금융|돈)/.test(q))return `이번 달 지출은 ${money(summary.monthExpense)}, 수입은 ${money(summary.monthIncome)}이에요. 차액은 ${money(summary.monthIncome-summary.monthExpense)}입니다. (LifeOS 기록 기준)`;
    if(/(할 일|할일|일정|해야)/.test(q))return `아직 완료하지 않은 할 일은 ${summary.incompleteTasks}개이고, 오늘부터 7일 안에 마감되는 할 일은 ${summary.dueSoonTasks}개예요.`;
    if(/(수면|잠|컨디션)/.test(q))return summary.recentSleepHours==null?'아직 수면 기록이 없어요. 먼저 수면 메뉴에서 기록을 추가해 보세요.':`최근 최대 7개 기록의 평균 수면 시간은 약 ${summary.recentSleepHours}시간이에요. 이 값은 입력된 취침·기상 시각을 바탕으로 계산했어요.`;
    return null;
  }
  async function ask(q:string){if(!q.trim()||working)return;setQuery('');setMessages(old=>[...old,{role:'user',text:q.trim()}]);const local=localAnswer(q);if(local){setMessages(old=>[...old,{role:'assistant',text:local}]);return;}
    if(!firebaseReady||!functions){setMessages(old=>[...old,{role:'assistant',text:'자유로운 AI 답변은 아직 연결되지 않았어요. Firebase Functions와 API 키를 설정한 후 이용할 수 있어요. 지출·할 일·수면 요약은 지금도 이용할 수 있습니다.'}]);return;}
    setWorking(true);
    try{const call=httpsCallable<{prompt:string;summary?:typeof summary},{answer:string}>(functions,'askLifeOS');const result=await call({prompt:q.trim().slice(0,1500),...(shareSummary?{summary}:{})});setMessages(old=>[...old,{role:'assistant',text:result.data.answer}]);}
    catch(e){const message=e instanceof Error?e.message:'AI 연결 오류';setMessages(old=>[...old,{role:'assistant',text:`AI 서버 요청에 실패했어요. 서버가 배포되었는지 확인해 주세요. (${message})`}]);}finally{setWorking(false);}
  }
  return <div className="stack-lg"><PageIntro eyebrow="PERSONAL ASSISTANT" title="LifeOS AI 비서" subtitle="생활 기록을 빠르게 요약하고 필요한 정보를 물어보세요."/>
    <div className="assistant-layout"><section className="assistant-card"><div className="chat-header"><div className="sparkle-circle"><Sparkles size={20}/></div><div><strong>LifeOS Assistant</strong><small>통계 요약 · 선택적 AI 대화</small></div><span className="status-dot"/></div>
      <div className="chat-scroll" aria-live="polite">{messages.map((m,i)=><div key={i} className={'chat-bubble '+m.role}>{m.text}</div>)}{working&&<div className="chat-bubble assistant"><LoaderCircle size={17} className="spinning"/> 답변 생성 중...</div>}</div>
      <div className="chat-prompts">{prompts.map(p=><button key={p} onClick={()=>void ask(p)}>{p}</button>)}</div>
      <form className="chat-form" onSubmit={e=>{e.preventDefault();void ask(query);}}><input aria-label="AI 질문" value={query} onChange={e=>setQuery(e.target.value)} maxLength={1500} placeholder="무엇을 도와드릴까요?"/><button className="btn primary" disabled={working||!query.trim()} aria-label="전송"><Send size={18}/></button></form>
    </section>
    <section className="panel assistant-info"><div className="sparkle-circle"><Check size={20}/></div><h2>내 데이터를 안전하게</h2><p>지출, 일정, 수면에 관한 기본 요약은 앱 안에서 계산돼요. 자유로운 AI 질문만 서버로 전송됩니다.</p><label className="toggle-line"><input type="checkbox" checked={shareSummary} onChange={e=>setShareSummary(e.target.checked)}/> AI 질문과 함께 요약 통계 전송 허용</label><p className="muted small">활성화하면 할 일 개수, 월별 수입·지출 총액, 최근 수면 평균 등이 AI 서버로 전달돼요. 메모 본문이나 개별 거래 내역은 전달하지 않습니다.</p><div className="tip-box"><Sparkles size={17}/> AI 응답은 참고용이며 중요한 결정 전 확인이 필요합니다.</div><p className="muted small">AI 서버 기능은 별도 배포 및 사용량에 따른 비용이 필요할 수 있어요.</p></section></div>
  </div>;
}
