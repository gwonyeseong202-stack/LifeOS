import { useState, type FormEvent } from 'react';
import { createUserWithEmailAndPassword, sendPasswordResetEmail, signInWithEmailAndPassword, signInWithPopup, signOut, GoogleAuthProvider } from 'firebase/auth';
import { ArrowUpRight, CalendarDays, ChevronRight, CircleHelp, Cloud, Download, House, Lightbulb, LogOut, Menu, Moon, Plus, Settings, Sparkles, Wallet, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { auth, firebaseReady } from './lib/firebase';
import { useUser } from './lib/useAuth';
import { useStore, type DataStore } from './lib/store';
import type { PageKey } from './lib/types';
import { dateLabel, isoDate, money, sleepLabel, sleepMinutes } from './lib/types';
import { AssistantPage, CalendarPage, FinancePage, NotesPage, SleepPage } from './pages/Pages';

const nav: { key: PageKey; label: string; icon: LucideIcon }[] = [
  { key: 'home', label: '홈', icon: House },
  { key: 'calendar', label: '일정', icon: CalendarDays },
  { key: 'finance', label: '금융', icon: Wallet },
  { key: 'notes', label: '메모', icon: Lightbulb },
  { key: 'sleep', label: '수면', icon: Moon },
  { key: 'assistant', label: 'AI 비서', icon: Sparkles },
];
const shortDays = ['일','월','화','수','목','금','토'];

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [register, setRegister] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!auth) return;
    setBusy(true); setError('');
    try {
      if (register) await createUserWithEmailAndPassword(auth, email, password);
      else await signInWithEmailAndPassword(auth, email, password);
    } catch (e) { setError(e instanceof Error ? e.message : '로그인에 실패했습니다.'); }
    finally { setBusy(false); }
  }
  async function google() {
    if (!auth) return; setBusy(true); setError('');
    try { await signInWithPopup(auth, new GoogleAuthProvider()); }
    catch (e) { setError(e instanceof Error ? e.message : 'Google 로그인에 실패했습니다.'); }
    finally { setBusy(false); }
  }
  async function reset() {
    if (!auth || !email) { setError('이메일을 먼저 입력하세요.'); return; }
    try { await sendPasswordResetEmail(auth, email); setError('비밀번호 재설정 메일을 요청했어요. 메일함을 확인하세요.'); }
    catch (e) { setError(e instanceof Error ? e.message : '재설정 메일 요청 실패'); }
  }
  return <div className="auth-wrap"><div className="auth-card">
    <div className="brand-mark big">L</div><p className="eyebrow">YOUR PERSONAL SYSTEM</p><h1>LifeOS에 오신 것을<br/>환영합니다.</h1>
    <p className="muted">나의 일정, 소비, 메모, 수면을 하나로.</p>
    <form onSubmit={submit} className="stack-md">
      <label>이메일<input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@example.com" required autoComplete="email" /></label>
      <label>비밀번호<input type="password" minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="6자 이상" required autoComplete={register ? 'new-password' : 'current-password'} /></label>
      <button className="btn primary wide" disabled={busy}>{busy ? '처리 중...' : register ? '새 계정 만들기' : '로그인'}</button>
    </form>
    <button className="btn secondary wide" onClick={google} disabled={busy}>Google 계정으로 계속</button>
    {error && <p className="alert">{error}</p>}
    <div className="auth-actions"><button className="text-btn" onClick={() => { setRegister(!register); setError(''); }}>{register ? '이미 계정이 있어요' : '계정 만들기'}</button><button className="text-btn" onClick={reset}>비밀번호 재설정</button></div>
  </div></div>;
}

function Home({ store, onPage, onAdd }: { store: DataStore; onPage: (p: PageKey) => void; onAdd: (p: PageKey) => void }) {
  const today = isoDate();
  const currentMonth = today.slice(0, 7);
  const greeting = new Date().getHours() < 12 ? '좋은 아침이에요' : new Date().getHours() < 18 ? '좋은 오후예요' : '오늘 하루도 수고했어요';
  const eventsToday = store.events.filter(e => e.date === today).sort((a, b) => a.time.localeCompare(b.time));
  const tasksToday = [...store.tasks].filter(t => !t.done).sort((a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999')).slice(0, 4);
  const monthExpenses = store.transactions.filter(t => t.kind === 'expense' && t.date.startsWith(currentMonth)).reduce((s, t) => s + t.amount, 0);
  const monthIncome = store.transactions.filter(t => t.kind === 'income' && t.date.startsWith(currentMonth)).reduce((s, t) => s + t.amount, 0);
  const lastSleep = [...store.sleepRecords].sort((a, b) => b.date.localeCompare(a.date))[0];
  const doneCount = store.tasks.filter(t => t.done).length;
  const niceDate = `${new Date().getMonth() + 1}월 ${new Date().getDate()}일 ${shortDays[new Date().getDay()]}요일`;
  return <div className="stack-xl">
    <section className="hero"><div className="hero-text"><span className="eyebrow">{niceDate} · MY DAY</span><h1>{greeting}<span className="hero-accent">.</span></h1><p>오늘 필요한 일들을 한눈에 확인하세요.</p></div><div className="hero-orbit"><div className="orbit-core"><Sparkles size={30}/></div></div></section>
    <div className="stats-grid">
      <button className="stat-card" onClick={() => onPage('calendar')}><div className="stat-top"><span>남은 할 일</span><CalendarDays size={19}/></div><strong>{store.tasks.filter(t => !t.done).length}<small>개</small></strong><span className="stat-foot">완료 {doneCount}개 <ArrowUpRight size={14}/></span></button>
      <button className="stat-card" onClick={() => onPage('finance')}><div className="stat-top"><span>이번 달 지출</span><Wallet size={19}/></div><strong className="money-stat">{money(monthExpenses)}</strong><span className="stat-foot">수입 {money(monthIncome)} <ArrowUpRight size={14}/></span></button>
      <button className="stat-card" onClick={() => onPage('sleep')}><div className="stat-top"><span>최근 수면 기록</span><Moon size={19}/></div><strong>{lastSleep ? sleepLabel(sleepMinutes(lastSleep.bedtime, lastSleep.wakeTime)) : '기록 없음'}</strong><span className="stat-foot">{lastSleep ? dateLabel(lastSleep.date) : '오늘부터 기록해 보세요'} <ArrowUpRight size={14}/></span></button>
      <button className="stat-card" onClick={() => onPage('notes')}><div className="stat-top"><span>저장한 메모</span><Lightbulb size={19}/></div><strong>{store.notes.length}<small>개</small></strong><span className="stat-foot">아이디어와 북마크 <ArrowUpRight size={14}/></span></button>
    </div>
    <div className="home-columns">
      <section className="panel"><div className="section-heading"><div><p className="eyebrow">FOCUS</p><h2>할 일</h2></div><button className="icon-btn" aria-label="할 일 추가" onClick={() => onAdd('calendar')}><Plus size={20}/></button></div>
        {tasksToday.length ? <div className="items">{tasksToday.map(t => <div key={t.id} className="mini-item"><span className={'dot ' + t.priority}/><div className="flex1"><strong>{t.title}</strong><small>{t.dueDate ? dateLabel(t.dueDate) : '마감일 없음'}</small></div></div>)}</div> : <div className="empty-small">남은 할 일이 없어요. 새로운 목표를 추가해 보세요.</div>}
        <button className="panel-link" onClick={() => onPage('calendar')}>전체 일정 보기 <ChevronRight size={16}/></button></section>
      <section className="panel"><div className="section-heading"><div><p className="eyebrow">CALENDAR</p><h2>오늘의 일정</h2></div><button className="icon-btn" aria-label="일정 추가" onClick={() => onAdd('calendar')}><Plus size={20}/></button></div>
        {eventsToday.length ? <div className="items">{eventsToday.map(e => <div key={e.id} className="mini-item"><span className="time-pill">{e.time || '종일'}</span><div className="flex1"><strong>{e.title}</strong><small>{e.details || '오늘의 일정'}</small></div></div>)}</div> : <div className="empty-small">오늘 등록한 일정이 없어요.</div>}
        <button className="panel-link" onClick={() => onPage('calendar')}>캘린더 열기 <ChevronRight size={16}/></button></section>
    </div>
    <button className="assistant-promo" onClick={() => onPage('assistant')}><span className="sparkle-circle"><Sparkles size={22}/></span><span><strong>생활 요약이 필요할 때</strong><small>LifeOS AI 비서에게 물어보세요</small></span><ArrowUpRight size={19}/></button>
  </div>;
}

function SettingsDialog({ store, onClose }: { store: DataStore; onClose: () => void }) {
  return <div className="overlay" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="dialog"><div className="section-heading"><h2>설정 및 데이터</h2><button className="icon-btn" onClick={onClose} aria-label="닫기"><X size={20}/></button></div>
    <div className="info-row"><span>화면 모드</span><b>기기 설정에 따라 자동</b></div><div className="info-row"><span>저장 방식</span><b>{firebaseReady ? 'Firebase 동기화' : '이 기기 로컬 체험'}</b></div>
    <p className="muted small">공유 기기에서는 로그아웃하고 브라우저 저장 데이터를 관리하세요. 오프라인 캐시는 기기에 남을 수 있습니다.</p>
    <button className="btn secondary wide" onClick={store.exportData}><Download size={17}/> 모든 데이터 JSON 백업</button>
    {auth && <button className="btn danger wide" onClick={() => { void signOut(auth); onClose(); }}><LogOut size={17}/> 로그아웃</button>}
  </div></div>;
}

function Shell({ uid, email }: { uid: string; email: string }) {
  const [page, setPage] = useState<PageKey>('home');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [quickOpen, setQuickOpen] = useState(false);
  const [requestAdd, setRequestAdd] = useState<{ page: PageKey; stamp: number } | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const store = useStore(uid);
  const go = (next: PageKey) => { setPage(next); setQuickOpen(false); setSidebarOpen(false); };
  const add = (next: PageKey) => { setRequestAdd({ page: next, stamp: Date.now() }); go(next); };
  const header = nav.find(n => n.key === page);
  return <div className="app-shell">
    <aside className={'sidebar ' + (sidebarOpen ? 'open' : '')}>
      <div className="brand"><span className="brand-mark">L</span><span>LifeOS<small>PERSONAL WORKSPACE</small></span></div>
      <span className="sidebar-title">WORKSPACE</span>
      <nav className="side-nav">{nav.map(n => <button key={n.key} className={'nav-item ' + (page === n.key ? 'selected' : '')} onClick={() => go(n.key)}><n.icon size={19}/>{n.label}{page === n.key && <span className="nav-indicator"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="side-account"><div className="avatar">{email.charAt(0).toUpperCase() || 'L'}</div><div><strong>{firebaseReady ? '내 계정' : '로컬 체험 모드'}</strong><small>{email}</small></div></div><button className="nav-item" onClick={() => setSettingsOpen(true)}><Settings size={19}/>설정</button></div>
    </aside>
    {sidebarOpen && <div className="mobile-shade" onClick={() => setSidebarOpen(false)}/>}
    <div className="main-area">
      <header className="topbar"><button className="icon-btn menu-btn" onClick={() => setSidebarOpen(true)} aria-label="메뉴"><Menu size={22}/></button><div className="breadcrumbs">내 공간 <ChevronRight size={14}/><strong>{header?.label}</strong></div><div className="top-actions"><span className="sync-state"><Cloud size={15}/>{firebaseReady ? '동기화 연결' : '로컬 체험'}</span><button className="icon-btn" aria-label="설정" onClick={() => setSettingsOpen(true)}><Settings size={20}/></button></div></header>
      {!firebaseReady && <div className="demo-notice"><CircleHelp size={16}/> 로컬 체험 모드입니다. 이 기기에만 저장되며 Firebase 설정 후 기존 체험 데이터는 자동 이전되지 않습니다.</div>}
      {store.error && <div className="error-banner">{store.error}</div>}
      <main className="content">
        {store.loading ? <div className="loading">생활 기록을 불러오는 중...</div> : <>
          {page === 'home' && <Home store={store} onPage={go} onAdd={add}/>}
          {page === 'calendar' && <CalendarPage store={store} requestAdd={requestAdd?.page === page ? requestAdd.stamp : undefined}/>}
          {page === 'finance' && <FinancePage store={store} requestAdd={requestAdd?.page === page ? requestAdd.stamp : undefined}/>}
          {page === 'notes' && <NotesPage store={store} requestAdd={requestAdd?.page === page ? requestAdd.stamp : undefined}/>}
          {page === 'sleep' && <SleepPage store={store} requestAdd={requestAdd?.page === page ? requestAdd.stamp : undefined}/>}
          {page === 'assistant' && <AssistantPage store={store}/>}
        </>}
      </main>
    </div>
    <div className="quick-add-wrap">{quickOpen && <div className="quick-pop"><p className="eyebrow">빠르게 기록</p>{([{ p: 'calendar', label: '일정·할 일', icon: CalendarDays }, { p: 'finance', label: '수입·지출', icon: Wallet }, { p: 'notes', label: '메모·북마크', icon: Lightbulb }, { p: 'sleep', label: '수면·컨디션', icon: Moon }] as { p: PageKey; label: string; icon: LucideIcon }[]).map(x => <button key={x.p} onClick={() => add(x.p)}><x.icon size={18}/>{x.label}</button>)}</div>}<button className={'fab ' + (quickOpen ? 'rotated' : '')} onClick={() => setQuickOpen(!quickOpen)} aria-label="빠른 추가"><Plus size={26}/></button></div>
    <nav className="bottom-nav">{nav.map(n => <button key={n.key} className={page === n.key ? 'selected' : ''} onClick={() => go(n.key)}><n.icon size={19}/><span>{n.label}</span></button>)}</nav>
    {settingsOpen && <SettingsDialog store={store} onClose={() => setSettingsOpen(false)}/>}
  </div>;
}

export default function App() {
  const { user, loading } = useUser();
  if (loading) return <div className="boot"><div className="brand-mark big">L</div><p>LifeOS 시작 중...</p></div>;
  if (firebaseReady && !user) return <Login/>;
  return <Shell uid={user?.uid || 'demo'} email={user?.email || '이 기기에만 저장'}/>;
}
