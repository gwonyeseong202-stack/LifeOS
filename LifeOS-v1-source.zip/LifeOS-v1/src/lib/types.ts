export interface BaseRecord { id: string; createdAt: number; updatedAt: number; }
export type Priority = 'low' | 'normal' | 'high';
export interface Task extends BaseRecord { title: string; done: boolean; priority: Priority; dueDate: string; notes: string; }
export interface CalendarEvent extends BaseRecord { title: string; date: string; time: string; details: string; }
export type MoneyKind = 'expense' | 'income';
export interface Transaction extends BaseRecord { title: string; amount: number; kind: MoneyKind; category: string; date: string; }
export interface Note extends BaseRecord { title: string; content: string; url: string; tag: string; pinned: boolean; }
export interface SleepRecord extends BaseRecord { date: string; bedtime: string; wakeTime: string; mood: number; memo: string; }
export interface Budget extends BaseRecord { month: string; amount: number; }
export interface Records {
  tasks: Task;
  events: CalendarEvent;
  transactions: Transaction;
  notes: Note;
  sleepRecords: SleepRecord;
  budgets: Budget;
}
export type CollectionKey = keyof Records;
export type NewRecord<K extends CollectionKey> = Omit<Records[K], keyof BaseRecord>;
export type PageKey = 'home' | 'calendar' | 'finance' | 'notes' | 'sleep' | 'assistant';
export function isoDate(d = new Date()) {
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}
export const money = (value: number) => new Intl.NumberFormat('ko-KR').format(value) + '원';
export const dateLabel = (value: string) => value ? value.replaceAll('-', '.') : '날짜 없음';
export function sleepMinutes(bedtime: string, wakeTime: string) {
  const [bh, bm] = bedtime.split(':').map(Number);
  const [wh, wm] = wakeTime.split(':').map(Number);
  if (![bh, bm, wh, wm].every(Number.isFinite)) return 0;
  const raw = (wh * 60 + wm) - (bh * 60 + bm);
  // An identical time is not assumed to mean 24h.
  return raw === 0 ? 0 : (raw + 1440) % 1440;
}
export function sleepLabel(minutes: number) { return `${Math.floor(minutes / 60)}시간 ${minutes % 60}분`; }
