import { useEffect, useState } from 'react';
import { collection, deleteDoc, doc, onSnapshot, setDoc } from 'firebase/firestore';
import { db, firebaseReady } from './firebase';
import type { CollectionKey, NewRecord, Records } from './types';

const keys: CollectionKey[] = ['tasks', 'events', 'transactions', 'notes', 'sleepRecords', 'budgets'];
export type DataStore = {
  [K in CollectionKey]: Records[K][];
} & {
  loading: boolean;
  error: string;
  add: <K extends CollectionKey>(kind: K, payload: NewRecord<K>) => Promise<void>;
  edit: <K extends CollectionKey>(kind: K, id: string, patch: Partial<NewRecord<K>>) => Promise<void>;
  remove: (kind: CollectionKey, id: string) => Promise<void>;
  exportData: () => void;
};

function localKey(kind: CollectionKey) { return `lifeos-v1:${kind}`; }
function loadLocal<K extends CollectionKey>(kind: K): Records[K][] {
  try { return JSON.parse(localStorage.getItem(localKey(kind)) || '[]') as Records[K][]; }
  catch { return []; }
}
function writeLocal<K extends CollectionKey>(kind: K, records: Records[K][]) {
  localStorage.setItem(localKey(kind), JSON.stringify(records));
  window.dispatchEvent(new Event('lifeos:changed'));
}

export function useStore(uid: string): DataStore {
  const [state, setState] = useState<{ [K in CollectionKey]: Records[K][] }>({
    tasks: [], events: [], transactions: [], notes: [], sleepRecords: [], budgets: [],
  });
  const [loaded, setLoaded] = useState<Set<CollectionKey>>(new Set());
  const [error, setError] = useState('');

  useEffect(() => {
    setLoaded(new Set());
    setError('');
    if (!firebaseReady || !db) {
      const refresh = () => {
        setState({ tasks: loadLocal('tasks'), events: loadLocal('events'), transactions: loadLocal('transactions'), notes: loadLocal('notes'), sleepRecords: loadLocal('sleepRecords'), budgets: loadLocal('budgets') });
        setLoaded(new Set(keys));
      };
      refresh();
      window.addEventListener('lifeos:changed', refresh);
      window.addEventListener('storage', refresh);
      return () => { window.removeEventListener('lifeos:changed', refresh); window.removeEventListener('storage', refresh); };
    }
    const unsub = keys.map(kind => onSnapshot(collection(db, 'users', uid, kind), snapshot => {
      const docs = snapshot.docs.map(item => ({ ...item.data(), id: item.id })) as Records[typeof kind][];
      setState(prev => ({ ...prev, [kind]: docs }));
      setLoaded(prev => new Set([...prev, kind]));
    }, e => { setError(`데이터 동기화 오류: ${e.message}`); setLoaded(prev => new Set([...prev, kind])); }));
    return () => unsub.forEach(un => un());
  }, [uid]);

  async function write<K extends CollectionKey>(kind: K, value: Records[K]) {
    if (db && firebaseReady) {
      const { id, ...fields } = value;
      void id;
      await setDoc(doc(db, 'users', uid, kind, id), fields);
    } else {
      const all = loadLocal(kind);
      const filtered = all.filter(x => x.id !== value.id);
      writeLocal(kind, [...filtered, value]);
    }
  }
  async function add<K extends CollectionKey>(kind: K, payload: NewRecord<K>) {
    const now = Date.now();
    await write(kind, { ...payload, id: crypto.randomUUID(), createdAt: now, updatedAt: now } as Records[K]);
  }
  async function edit<K extends CollectionKey>(kind: K, id: string, patch: Partial<NewRecord<K>>) {
    // Firestore merge avoids stale UI overwriting fields edited on another device.
    if (db && firebaseReady) {
      await setDoc(doc(db, 'users', uid, kind, id), { ...patch, updatedAt: Date.now() }, { merge: true });
    } else {
      const records = loadLocal(kind);
      writeLocal(kind, records.map(r => r.id === id ? { ...r, ...patch, updatedAt: Date.now() } : r));
    }
  }
  async function remove(kind: CollectionKey, id: string) {
    if (db && firebaseReady) await deleteDoc(doc(db, 'users', uid, kind, id));
    else writeLocal(kind, loadLocal(kind).filter(r => r.id !== id));
  }
  function exportData() {
    const result = { version: 1, exportedAt: new Date().toISOString(), data: state };
    const url = URL.createObjectURL(new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `lifeos-backup-${new Date().toISOString().slice(0,10)}.json`;
    anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return { ...state, loading: loaded.size !== keys.length, error, add, edit, remove, exportData };
}
