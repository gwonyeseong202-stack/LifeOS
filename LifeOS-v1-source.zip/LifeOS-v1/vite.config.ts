import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

// GitHub Pages: VITE_BASE_PATH=/<repository-name>/
const base = process.env.VITE_BASE_PATH || '/';

export default defineConfig({
  base,
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'apple-touch-icon.png'],
      manifest: {
        name: 'LifeOS — 나의 생활 관리',
        short_name: 'LifeOS',
        description: '나의 일정, 지출, 메모, 수면을 한곳에',
        start_url: base,
        scope: base,
        display: 'standalone',
        theme_color: '#101b2e',
        background_color: '#f5f7fb',
        lang: 'ko',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
        ],
      },
      workbox: {
        navigateFallback: `${base}index.html`,
        globPatterns: ['**/*.{js,css,html,svg,png}'],
        maximumFileSizeToCacheInBytes: 3500000,
        // Personal records are never cached by the service worker.
      },
    }),
  ],
});
