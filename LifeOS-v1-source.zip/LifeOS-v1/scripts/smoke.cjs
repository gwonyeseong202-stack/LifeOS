/* Dependency-free structural smoke test. For a complete check, run npm run build. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const ts = require('typescript');
const root = path.resolve(__dirname,'..');
const parse = file => JSON.parse(fs.readFileSync(path.join(root,file),'utf8'));
for (const p of ['package.json','firebase.json','functions/package.json']) parse(p);
for (const p of ['src/App.tsx','src/pages/Pages.tsx','src/lib/store.ts','src/lib/firebase.ts','src/lib/types.ts','src/lib/useAuth.ts','src/main.tsx','vite.config.ts']) {
  const source=fs.readFileSync(path.join(root,p),'utf8');
  const result=ts.transpileModule(source,{fileName:p,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}});
  assert.equal(result.diagnostics?.length||0,0,`${p} has syntax errors`);
}
for(const size of [192,512]){const b=fs.readFileSync(path.join(root,`public/icon-${size}.png`));assert.equal(b.toString('hex',1,4),'504e47');}
console.log('PASS: config, TypeScript/TSX syntax, PWA icon files');
