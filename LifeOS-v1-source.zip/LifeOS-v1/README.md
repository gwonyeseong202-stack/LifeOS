# LifeOS 1.0 — 생활 관리 PWA

**갤럭시 스마트폰·태블릿에서 사용하는 개인 생활 관리 웹앱**입니다. React + TypeScript + Vite, Firebase Authentication/Firestore, 선택적 Firebase Cloud Functions AI, GitHub Pages 기반입니다.

## 포함된 기능

- **홈:** 오늘의 일정/할 일, 이번 달 지출·수입, 최근 수면, 메모 수 요약
- **일정/할 일:** 등록, 수정, 삭제, 완료 체크, 월별 조회, 우선순위
- **금융:** 수입·지출 등록/수정/삭제, 분류별 그래프, 월 예산 (Firebase 시 동기화)
- **메모/북마크:** 텍스트·웹 링크·태그, 검색, 고정, 수정/삭제
- **수면/컨디션:** 취침·기상 기록, 수면 시간 계산, 컨디션, 그래프
- **AI 비서:** 로컬 통계 질문(무료), 서버 연결 시 자연어 AI 대화(선택)
- **공통:** 시스템 라이트/다크 테마, PWA 설치, JSON 백업, Firebase 계정별 동기화
- **개인 장소 저장소:** 요구사항에 따라 제외됨

> 현재 프로젝트는 **작동 가능한 초기 구현 코드**입니다. GitHub 저장소 생성, Firebase 프로젝트 설정, 실제 배포는 아직 수행되지 않았습니다. 해당 계정과 설정은 직접 연결해야 합니다.

## 폴더 구성

```text
LifeOS-v1/
├── index.html
├── src/
│   ├── App.tsx                    # 메인 탐색, 로그인, 홈, 설정
│   ├── main.tsx                   # React 진입점
│   ├── styles.css                 # 반응형 디자인, 자동 테마
│   ├── pages/Pages.tsx            # 일정/금융/메모/수면/AI 화면
│   └── lib/
│       ├── firebase.ts           # Firebase SDK 초기화
│       ├── store.ts              # Firestore와 로컬 체험 데이터 CRUD
│       ├── types.ts              # 데이터 타입/계산 함수
│       └── useAuth.ts            # 로그인 상태 관리
├── public/
│   ├── favicon.svg
│   ├── icon-192.png
│   ├── icon-512.png
│   └── apple-touch-icon.png
├── functions/
│   ├── index.js                  # 서버 AI 호출 (API 키 비공개)
│   └── package.json
├── firestore.rules               # 계정별 DB 접근 권한
├── firebase.json
├── vite.config.ts                # PWA + Pages base
├── .env.example                  # 로컬 Firebase 설정 예시
└── .github/workflows/deploy.yml # Pages 자동 배포
```

## 1. 먼저 화면 실행해 보기 (Firebase 없이 가능)

Node.js 22 이상 설치 후 터미널에서:

```bash
npm install
npm run dev
```

정적 기본 검사: `npm run check` (TypeScript/TSX 구문과 필수 파일을 점검합니다. 전체 빌드 검사는 `npm run build`를 사용합니다.)

화면에 나타나는 주소에서 실행하면 **로컬 체험 모드**로 사용할 수 있습니다. 체험 모드의 기록은 현재 브라우저의 `localStorage`에 저장되며 **휴대폰·태블릿 사이에서 동기화되지 않습니다.** Firebase를 나중에 설정하면 로컬 체험 기록은 **자동 이전되지 않습니다.** 필요한 경우 설정에서 JSON 백업을 다운로드해 두세요(1.0은 JSON 복원 UI 미구현).

프로덕션 확인:

```bash
npm run build
npm run preview
```

## 2. Firebase 연결 (기기 간 동기화)

1. https://console.firebase.google.com/ 에서 프로젝트를 만들고 **웹 앱**을 추가합니다.
2. **Authentication → Sign-in method**에서 `Email/Password`를 켭니다. 필요하면 `Google`도 켭니다.
3. **Firestore Database**를 생성합니다. 데이터베이스의 접근 권한은 아래 규칙 배포 후 사용합니다.
4. 프로젝트 설정에 나온 웹 앱 설정값을 `.env.example`에서 `.env`로 복사한 뒤 채웁니다.
5. `firebase.json`, `firestore.rules`는 프로젝트에 포함되어 있습니다. Firebase CLI 사용 시:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore:rules
```

`firebase use --add`에서 만든 Firebase 프로젝트를 선택하세요. `.firebaserc.example`은 참고용이며 실제 `.firebaserc`는 CLI로 생성할 수 있습니다.

**주의:** Firestore 규칙을 배포하지 않으면 데이터 저장이 `permission-denied` 오류로 실패할 수 있습니다. 테스트를 위해 영구적으로 모든 사용자에게 읽기/쓰기를 허용하지 마세요.

### Firebase Google 로그인과 Pages

Authentication → Settings → **Authorized domains**에 `YOUR_USERNAME.github.io`를 추가해야 할 수 있습니다. `https://` 또는 리포지토리 경로 없이 **호스트명**만 입력하세요. 이메일/비밀번호 로그인은 별도의 Google OAuth 팝업 제약이 상대적으로 적습니다.

## 3. GitHub Pages에 배포

1. GitHub에서 `LifeOS` 등의 이름으로 새 저장소를 만듭니다.
2. 이 ZIP 파일을 압축 해제하여 **프로젝트 안의 파일과 숨김 `.github` 폴더까지** 리포지토리 최상위에 업로드합니다. **ZIP 파일 하나만 업로드하면 앱이 배포되지 않습니다.**
3. 저장소 **Settings → Secrets and variables → Actions → New repository secret**에서 다음 환경 변수와 같은 이름의 Repository Secret을 만듭니다(값은 Firebase 웹 설정에서 복사).
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_APP_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET` (선택)
   - `VITE_FIREBASE_MESSAGING_SENDER_ID` (선택)
4. **Settings → Pages → Build and deployment → Source: GitHub Actions**를 선택합니다.
5. `main` 브랜치에 푸시하면 `.github/workflows/deploy.yml`이 실행됩니다.
6. 보통 `https://YOUR_USERNAME.github.io/YOUR_REPOSITORY/` 주소에서 접속합니다.
7. 배포 주소를 Chrome(갤럭시)에서 열고 메뉴의 **홈 화면에 추가/앱 설치**를 선택합니다.

`vite.config.ts`의 Pages 기본 경로는 Actions가 저장소 이름으로 자동 설정하므로 대개 손댈 필요가 없습니다. 다른 이름의 브랜치를 쓰면 workflow의 `branches: [main]`도 바꾸세요.

> 모바일만 있다면 GitHub Codespaces 또는 github.dev의 웹 편집기를 사용해 프로젝트 파일을 업로드/수정할 수 있습니다. Codespaces에서는 ZIP을 업로드한 다음 터미널에서 압축 해제하고 `npm install` 및 Git 푸시를 수행할 수 있습니다. 웹 도구의 메뉴는 환경에 따라 다를 수 있습니다.

### ⚠️ Firebase 웹 설정 vs AI 비밀키

`VITE_FIREBASE_*` 설정은 **웹 클라이언트에 포함되는 공개 설정값**입니다. 앱 보안은 Firebase Authentication과 Firestore Rules로 유지됩니다. 하지만 **`OPENAI_API_KEY`는 절대로 `VITE_` 변수, 저장소, 클라이언트 코드에 넣으면 안 됩니다.**

## 4. AI 비서 실제 응답 사용 (선택)

AI 비서에는 두 단계가 있습니다.

- **기본 통계 답변:** 지출, 할 일, 수면을 묻는 질문은 앱에서 계산해서 반환합니다. AI 서버가 없어도 동작합니다.
- **자유로운 AI 대화:** Firebase Cloud Function `askLifeOS`를 별도로 배포해야 작동합니다. Firestore 로그인으로 요청을 인증하며, 계정당 시간당 최대 12회 서버 제한이 있습니다.

서버 기능을 배포하려면 Firebase 프로젝트의 **Blaze(사용량 기반 결제) 요금제**가 요구될 수 있고, OpenAI API는 ChatGPT 구독과 별도로 **사용량에 따라 비용이 청구**됩니다. 결제는 보호자와 비용 및 한도를 확인한 뒤 진행하는 편이 좋습니다.

```bash
cd functions
npm install
cd ..
firebase functions:secrets:set OPENAI_API_KEY
firebase deploy --only functions
```

AI 모델은 `functions/index.js`에서 `gpt-4.1-mini`로 지정했습니다. 해당 모델의 제공 여부와 요금은 배포 시점에 OpenAI API 문서를 확인하세요. 서버 함수는 `asia-northeast3`(서울)에서 배포되도록 설정했습니다.

### AI와 프라이버시

- AI 채팅에 입력한 질문은 서버 AI 호출 시 외부 API로 전송됩니다.
- **요약 통계 전송 허용** 체크박스를 켜야 지출 합계, 할 일 개수, 수면 평균 등의 집계가 함께 전송됩니다.
- 메모 본문, 특정 거래 내용, 개인 계정 정보는 자동으로 AI에게 전달하지 않습니다.
- AI 호출에서 응답 `store: false`를 설정했습니다. 플랫폼의 별도 보안 및 보존 정책 적용 가능성을 확인하세요.
- 개인 자격 증명, 계좌번호, 비밀번호를 AI 입력창에 적지 마세요.

## 5. 알려진 한계 / 다음 작업

- 1.0은 한 화면에 모든 기능을 넣지 않고 **탭별 화면**으로 구성합니다.
- 브라우저/Android의 알림 권한과 백그라운드 제약 때문에 **푸시 알림은 미구현**입니다.
- 다른 기기에서 동시에 같은 필드를 수정하면 **마지막 저장이 우선**할 수 있습니다.
- 수면 시간은 24시간 이내로 가정해 취침~기상 시각 차이를 계산합니다. 특수한 경우 수정 기록이 필요합니다.
- **JSON 백업 내보내기 가능**, 복원 기능은 미구현입니다.
- **은행 자동 연동 없음**, 수입/지출은 수동 입력입니다.
- 정기 결제, 반복 일정, 파일 첨부, 캘린더 API 연동은 후속 버전에서 추가 예정입니다.
- AI는 **일정이나 결제를 자동 실행하지 않습니다.** 질문에 답하는 형태입니다.
- Firestore 캐시와 로컬 체험 데이터는 기기에 남을 수 있습니다. 공유/공용 기기에서 사용하지 않는 것이 좋습니다.
- Firebase에서 보안 규칙은 기본적으로 본인 UID의 문서 접근만 허용하지만, 금융 앱으로 상용 출시하려면 입력 검증, 백업/복원, 데이터 삭제, 사용량 제한, 모니터링 등을 추가로 검토해야 합니다.

## 참고 문서

- [Vite GitHub Pages 배포](https://vite.dev/guide/static-deploy)
- [Firebase 웹 인증](https://firebase.google.com/docs/auth/web/start)
- [Firestore 오프라인 캐시](https://firebase.google.com/docs/firestore/manage-data/enable-offline)
- [Firebase Callable Functions](https://firebase.google.com/docs/functions/callable)
- [Firebase Secret Manager](https://firebase.google.com/docs/functions/config-env)
- [vite-plugin-pwa](https://vite-pwa-org.netlify.app/)
- [OpenAI Responses API](https://platform.openai.com/docs/api-reference/responses)
